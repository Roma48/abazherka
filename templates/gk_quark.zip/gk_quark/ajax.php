<?php
/**
 *
 * AJAX view
 *
 * @version             3.0.0
 * @package             Gavern Framework
 * @copyright			Copyright (C) 2010 - 2012 GavickPro. All rights reserved.
 *               
 */
 
// No direct access.
defined('_JEXEC') or die;
?>

<jdoc:include type="message" />
<jdoc:include type="component" />