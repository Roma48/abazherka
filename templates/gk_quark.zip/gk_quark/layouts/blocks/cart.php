<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
        
<div id="gkPopupCart">        
	<div class="gkPopupWrap">        
		<div id="gkAjaxCart"></div>
	</div>
</div>